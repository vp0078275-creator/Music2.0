package com.music.two

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val STORAGE_PERMISSION_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val discImageView: ImageView = findViewById(R.id.discImageView)
        val playButton: Button = findViewById(R.id.playButton)

        // Storage permission aur media scanning check karne ke liye function call
        checkAndRequestPermission()

        playButton.setOnClickListener {
            Toast.makeText(this, "Music 2.0 Playing...", Toast.LENGTH_SHORT).show()
        }
    }

    // Runtime Permission Check Logic
    private fun checkAndRequestPermission() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadAudioFiles()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permission), STORAGE_PERMISSION_CODE)
        }
    }

    // Permission Result Handling
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted!", Toast.LENGTH_SHORT).show()
                loadAudioFiles()
            } else {
                Toast.makeText(this, "Permission Denied! Songs nahi load ho sakte.", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Local Audio Files (MediaStore) Scanning Logic
    private fun loadAudioFiles() {
        val audioList = mutableListOf<String>()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DATA
        )

        val cursor: Cursor? = contentResolver.query(uri, projection, null, null, null)
        cursor?.use {
            val titleColumn = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            while (it.moveToNext()) {
                val title = it.getString(titleColumn)
                audioList.add(title)
            }
        }

        if (audioList.isNotEmpty()) {
            Toast.makeText(this, "Total Songs Found: ${audioList.size}", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Koi gaana nahi mila phone mein!", Toast.LENGTH_SHORT).show()
        }
    }
}
