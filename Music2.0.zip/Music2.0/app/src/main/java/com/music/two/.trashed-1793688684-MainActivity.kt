package com.music.two

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var btnPlay: Button
    private lateinit var txtSongTitle: TextView
    private var isPlaying = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPlay = findViewById(R.id.btnPlay)
        txtSongTitle = findViewById(R.id.txtSongTitle)

        btnPlay.setOnClickListener {
            isPlaying = !isPlaying
            if (isPlaying) {
                txtSongTitle.text = "Playing: Vivo Vibe Track"
                Toast.makeText(this, "Music Started", Toast.LENGTH_SHORT).show()
            } else {
                txtSongTitle.text = "Paused"
                Toast.makeText(this, "Music Paused", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
