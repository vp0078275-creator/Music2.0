package com.music.two

import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var discContainer: View
    private lateinit var btnPlay: Button
    private lateinit var txtSongTitle: TextView
    private lateinit var txtArtist: TextView
    
    private var isPlaying = false
    private lateinit var rotateAnimator: ObjectAnimator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Views initialize kar rahe hain
        discContainer = findViewById(R.id.discContainer)
        btnPlay = findViewById(R.id.btnPlay)
        txtSongTitle = findViewById(R.id.txtSongTitle)
        txtArtist = findViewById(R.id.txtArtist)

        // Rotation Animation Setup (Vivo-style smooth continuous rotation)
        rotateAnimator = ObjectAnimator.ofFloat(discContainer, "rotation", 0f, 360f).apply {
            duration = 10000 // 10 seconds per full rotation
            repeatCount = ObjectAnimator.INFINITE
            interpolator = LinearInterpolator()
        }

        // Play / Pause Button Click Logic
        btnPlay.setOnClickListener {
            if (isPlaying) {
                // Pause State
                isPlaying = false
                rotateAnimator.pause()
                btnPlay.text = "Play"
                Toast.makeText(this, "Music Paused", Toast.LENGTH_SHORT).show()
            } else {
                // Play State
                isPlaying = true
                if (rotateAnimator.isPaused) {
                    rotateAnimator.resume()
                } else {
                    rotateAnimator.start()
                }
                btnPlay.text = "Pause"
                txtSongTitle.text = "Vivo Vibe Track"
                txtArtist.text = "Music 2.0 Official"
                Toast.makeText(this, "Playing Music", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
